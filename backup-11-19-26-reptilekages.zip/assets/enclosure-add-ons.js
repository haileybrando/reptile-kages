import { StandardEvents } from '@shopify/events';

const number = (value) => Number.parseFloat(String(value ?? '').replace(/[^0-9.-]/g, '')) || 0;
const roots = () => [...document.querySelectorAll('[data-enclosure-addons]')];
const parentId = (root) => String(root.dataset.parentProductId || '');
let cart = { items: [] };
let ready = false;
let syncing = null;
const pending = new Map();

function enclosureQuantity(id) {
  return cart.items.reduce((sum, item) => {
    if (String(item.product_id) !== id || item.properties?._addon_parent_product_id) return sum;
    return sum + Math.max(0, Number(item.quantity) || 0);
  }, 0);
}

function usage(id, capacity) {
  const quantity = enclosureQuantity(id);
  const widths = Array(quantity).fill(0);
  if (!quantity) return widths;
  const addons = cart.items.filter((item) => String(item.properties?._addon_parent_product_id || '') === id);
  const unassigned = [];
  for (const item of addons) {
    const properties = item.properties || {};
    const width = number(properties._addon_product_width);
    const count = Math.max(0, Number(item.quantity) || 0);
    if (!width || !count) continue;
    const assigned = Number.parseInt(properties._addon_enclosure_number, 10);
    if (assigned >= 1 && assigned <= quantity) {
      widths[assigned - 1] += width * count;
    } else {
      for (let i = 0; i < count; i++) unassigned.push(width);
    }
  }
  // Existing unnumbered add-ons are allocated conservatively; do not discard their width.
  for (const width of unassigned.sort((a, b) => b - a)) {
    const index = widths.findIndex((used) => used + width <= capacity + 0.001);
    if (index !== -1) widths[index] += width;
    else widths[widths.indexOf(Math.min(...widths))] += width;
  }
  for (const reservation of pending.get(id) || []) {
    if (reservation.enclosure <= quantity) widths[reservation.enclosure - 1] += reservation.width;
  }
  return widths;
}

function selectEnclosure(root, addonWidth) {
  const id = parentId(root);
  const quantity = enclosureQuantity(id);
  if (!quantity) return -1; // No enclosure yet: allow standalone add-ons.
  const capacity = number(root.dataset.maxWidth);
  if (!capacity || !addonWidth) return 1;
  const widths = usage(id, capacity);
  const index = widths.findIndex((used) => used + addonWidth <= capacity + 0.001);
  // Keep enclosure labels useful without restricting which add-ons can be purchased.
  return (index >= 0 ? index : widths.indexOf(Math.min(...widths))) + 1;
}

function refresh() {
  for (const root of roots()) {
    const capacity = number(root.dataset.maxWidth);
    const widths = usage(parentId(root), capacity);
    const meter = root.querySelector('[data-addon-width-meter]');
    if (meter) {
      const total = capacity * widths.length;
      const used = widths.reduce((sum, value) => sum + value, 0);
      const heading = meter.querySelector('[data-width-meter-capacity]');
      const label = meter.querySelector('[data-width-meter-label]');
      const fill = meter.querySelector('[data-width-meter-fill]');
      if (heading) heading.textContent = `${widths.length} enclosure${widths.length === 1 ? '' : 's'} × ${capacity}″ = ${total}″ available`;
      if (label) label.textContent = `${Math.max(0, total - used)}″ remaining`;
      if (fill) fill.style.width = `${total ? Math.min(100, 100 * used / total) : 0}%`;
    }
  }
}

async function syncCart() {
  if (syncing) return syncing;
  syncing = (async () => {
    try {
      const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart.js`, {
        credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
      });
      if (!response.ok) throw new Error(`Cart HTTP ${response.status}`);
      cart = await response.json();
      ready = true;
      pending.clear();
      refresh();
    } catch (error) {
      console.warn('[enclosure-add-ons] Could not refresh enclosure information', error);
      ready = false;
      refresh();
    } finally {
      syncing = null;
    }
  })();
  return syncing;
}

document.addEventListener('submit', (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  const root = form.closest('[data-enclosure-addons]');
  const card = form.closest('[data-addon-card]');
  if (!root || !card) return;
  const width = number(card.dataset.addonWidth);
  const enclosure = ready ? selectEnclosure(root, width) : -1;
  const assignment = form.querySelector('[name="properties[_addon_enclosure_number]"]');
  if (assignment) {
    assignment.disabled = enclosure === -1;
    if (enclosure > 0) assignment.value = String(enclosure);
  }
  const label = form.querySelector('[name="properties[For Product]"]');
  if (label) {
    const title = root.dataset.parentProductTitle || label.defaultValue;
    label.value = enclosure > 0 ? `${title} (${enclosure})` : title;
  }
  const id = parentId(root);
  if (enclosure > 0) pending.set(id, [...(pending.get(id) || []), { enclosure, width }]);
  refresh();
}, true);

document.addEventListener(StandardEvents.cartLinesUpdate, (event) => {
  if (event.promise) event.promise.then(syncCart, syncCart);
  else syncCart();
});
document.addEventListener('DOMContentLoaded', syncCart, { once: true });
if (document.readyState !== 'loading') syncCart();
