(() => {
  if (window.__addonFitValidatorV4Loaded) return;
  window.__addonFitValidatorV4Loaded = true;

  const pendingWidths = new Map();

  const toNumber = (value) => {
    const parsed = parseFloat(
      String(value || "").replace(/[^0-9.\-]/g, "")
    );

    return Number.isFinite(parsed) ? parsed : 0;
  };

  /**
   * Expected markup from blocks/product-recommendations.liquid:
   *
   * Wrapper:
   * data-addon-fit-root
   * data-parent-product-id="{{ product.id }}"
   * data-parent-product-width="{{ product.metafields.custom.product_width.value }}"
   *
   * Each add-on card:
   * data-addon-fit-item
   * data-addon-product-id="{{ addon_product.id }}"
   * data-addon-product-width="{{ addon_product.metafields.custom.product_width.value }}"
   */

  function getRoot(element) {
    return element?.closest("[data-addon-fit-root]");
  }

  function getItem(element) {
    return element?.closest("[data-addon-fit-item]");
  }

  function getContext(item) {
    if (!item) return null;

    const root = getRoot(item);

    if (!root) return null;

    return {
      root,
      item,
      parentProductId: String(
        root.dataset.parentProductId || ""
      ),
      parentWidth: toNumber(
        root.dataset.parentProductWidth
      ),
      addonProductId: String(
        item.dataset.addonProductId || ""
      ),
      addonWidth: toNumber(
        item.dataset.addonProductWidth
      ),
    };
  }

  function getPendingWidth(parentProductId) {
    return (
      pendingWidths.get(String(parentProductId)) || 0
    );
  }

  function reserveWidth(parentProductId, width) {
    const key = String(parentProductId);

    pendingWidths.set(
      key,
      getPendingWidth(key) + width
    );
  }

  function setMessage(item, message) {
    let messageElement =
      item.querySelector(".addon-fit-message");

    if (!message) {
      messageElement?.remove();
      return;
    }

    if (!messageElement) {
      messageElement =
        document.createElement("div");

      messageElement.className =
        "addon-fit-message";

      messageElement.setAttribute(
        "role",
        "status"
      );

      messageElement.style.cssText = `
        margin-top: 8px;
        font-size: 13px;
        line-height: 1.35;
      `;

      item.appendChild(messageElement);
    }

    messageElement.textContent = message;
  }

  /**
   * Read widths from add-ons already in the cart.
   *
   * V4 stores these line-item properties:
   *
   * _addon_parent_product_id
   * _addon_product_width
   */
  async function getCartWidths() {
    const widths = new Map();

    try {
      const response = await fetch(
        `${window.Shopify?.routes?.root || "/"}cart.js`,
        {
          credentials: "same-origin",
          headers: {
            Accept: "application/json",
          },
        }
      );

      if (!response.ok) {
        throw new Error(
          `cart.js returned ${response.status}`
        );
      }

      const cart = await response.json();

      for (const cartItem of cart.items || []) {
        const properties =
          cartItem.properties || {};

        const parentProductId = String(
          properties._addon_parent_product_id || ""
        );

        const addonWidth = toNumber(
          properties._addon_product_width
        );

        if (
          !parentProductId ||
          addonWidth <= 0
        ) {
          continue;
        }

        const quantity =
          Number(cartItem.quantity) || 1;

        widths.set(
          parentProductId,
          (widths.get(parentProductId) || 0) +
            addonWidth * quantity
        );
      }
    } catch (error) {
      console.warn(
        "[addon-fit-v4] Unable to read cart:",
        error
      );
    }

    return widths;
  }

  let cartWidths = new Map();

  function getUsedWidth(parentProductId) {
    const key = String(parentProductId);

    return (
      (cartWidths.get(key) || 0) +
      getPendingWidth(key)
    );
  }

  function canAdd(context) {
    if (!context) return true;

    if (
      !context.parentProductId ||
      context.parentWidth <= 0 ||
      context.addonWidth <= 0
    ) {
      return true;
    }

    const used =
      getUsedWidth(
        context.parentProductId
      );

    return (
      used + context.addonWidth <=
      context.parentWidth + 0.001
    );
  }

  function updateItems() {
    document
      .querySelectorAll(
        "[data-addon-fit-item]"
      )
      .forEach((item) => {
        const context =
          getContext(item);

        if (!context) return;

        if (
          context.parentWidth <= 0 ||
          context.addonWidth <= 0
        ) {
          setMessage(item, "");
          return;
        }

        const used =
          getUsedWidth(
            context.parentProductId
          );

        const total =
          used + context.addonWidth;

        const exceeds =
          total >
          context.parentWidth + 0.001;

        const buttons =
          item.querySelectorAll(
            `
              button[type="submit"],
              .quick-add__button,
              [data-add-to-cart],
              product-form button
            `
          );

        buttons.forEach((button) => {
          button.dataset.addonFitBlocked =
            exceeds ? "true" : "false";

          button.setAttribute(
            "aria-disabled",
            exceeds ? "true" : "false"
          );

          if (exceeds) {
            button.title =
              `This add-on requires ${context.addonWidth}" ` +
              `but only ${Math.max(
                0,
                context.parentWidth - used
              )}" remains.`;
          } else {
            button.removeAttribute(
              "title"
            );
          }
        });

        setMessage(
          item,
          exceeds
            ? `${used}" of the ` +
                `${context.parentWidth}" available ` +
                `width is already used. This add-on ` +
                `requires ${context.addonWidth}".`
            : ""
        );
      });
  }

  async function syncCart() {
    cartWidths =
      await getCartWidths();

    /**
     * Once cart.js has updated, pending widths
     * are represented by actual cart items.
     */
    pendingWidths.clear();

    updateItems();
  }

  function blockEvent(
    event,
    context
  ) {
    event.preventDefault();
    event.stopPropagation();

    if (
      typeof event.stopImmediatePropagation ===
      "function"
    ) {
      event.stopImmediatePropagation();
    }

    const used =
      getUsedWidth(
        context.parentProductId
      );

    const remaining =
      Math.max(
        0,
        context.parentWidth - used
      );

    setMessage(
      context.item,
      `Cannot add this item. ` +
        `${used}" of the ` +
        `${context.parentWidth}" width is already ` +
        `used, leaving ${remaining}". ` +
        `This add-on requires ` +
        `${context.addonWidth}".`
    );

    updateItems();
  }

  /**
   * Capture clicks BEFORE Horizon's quick-add
   * handlers receive them.
   */
  document.addEventListener(
    "click",
    (event) => {
      const button =
        event.target.closest(
          `
            .quick-add__button,
            [data-add-to-cart],
            product-form button,
            button[type="submit"]
          `
        );

      if (!button) return;

      const item =
        getItem(button);

      if (!item) return;

      const context =
        getContext(item);

      if (!context) return;

      if (!canAdd(context)) {
        blockEvent(
          event,
          context
        );

        return;
      }

      /**
       * Some Horizon cards open a quick-add modal
       * rather than immediately adding the item.
       *
       * Don't reserve width until the actual
       * product form submits.
       */
      const opensDialog =
        button.getAttribute(
          "aria-haspopup"
        ) === "dialog" ||
        button.hasAttribute(
          "data-product-modal"
        ) ||
        button.closest(
          "quick-add"
        )?.querySelector("dialog");

      if (opensDialog) {
        return;
      }

      reserveWidth(
        context.parentProductId,
        context.addonWidth
      );

      updateItems();

      setTimeout(syncCart, 500);
      setTimeout(syncCart, 1200);
    },
    true
  );

  /**
   * Capture direct product-form submissions.
   */
  document.addEventListener(
    "submit",
    (event) => {
      const form =
        event.target;

      if (
        !(form instanceof HTMLFormElement)
      ) {
        return;
      }

      const item =
        getItem(form);

      if (!item) return;

      const context =
        getContext(item);

      if (!context) return;

      if (!canAdd(context)) {
        blockEvent(
          event,
          context
        );

        return;
      }

      reserveWidth(
        context.parentProductId,
        context.addonWidth
      );

      updateItems();

      setTimeout(syncCart, 500);
      setTimeout(syncCart, 1200);
    },
    true
  );

  /**
   * Resync whenever Horizon announces a
   * cart change.
   */
  [
    "cart:update",
    "cart:updated",
    "cart:change",
    "cart:refresh",
  ].forEach((eventName) => {
    document.addEventListener(
      eventName,
      () => {
        setTimeout(
          syncCart,
          100
        );
      }
    );
  });

  /**
   * Horizon can dynamically redraw product
   * recommendation blocks.
   */
  let observerTimer;

  const observer =
    new MutationObserver(() => {
      clearTimeout(observerTimer);

      observerTimer =
        setTimeout(
          updateItems,
          50
        );
    });

  observer.observe(
    document.documentElement,
    {
      childList: true,
      subtree: true,
    }
  );

  if (
    document.readyState === "loading"
  ) {
    document.addEventListener(
      "DOMContentLoaded",
      syncCart,
      { once: true }
    );
  } else {
    syncCart();
  }
})();