import { Component } from '@theme/component';
import {
  fetchConfig,
  debounce,
  onAnimationEnd,
  prefersReducedMotion,
  resetShimmer,
  startViewTransition,
} from '@theme/utilities';
import { morphSection, sectionRenderer } from '@theme/section-renderer';
import { ThemeEvents, QuantitySelectorUpdateEvent } from '@theme/events';
import { cartPerformance } from '@theme/performance';
import {
  createViewEventElement,
  CartErrorEvent,
  CartDiscountUpdateEvent,
  CartLinesUpdateEvent,
  CartNoteUpdateEvent,
  StandardEvents,
} from '@shopify/events';

/** @typedef {import('./utilities').TextComponent} TextComponent */

/**
 * A custom element that displays a cart items component.
 *
 * @typedef {object} Refs
 * @property {HTMLElement[]} quantitySelectors - The quantity selector elements.
 * @property {HTMLTableRowElement[]} cartItemRows - The cart item rows.
 * @property {TextComponent} cartTotal - The cart total.
 *
 * @extends {Component<Refs>}
 */
export class CartItemsComponent extends createViewEventElement(Component) {
  #debouncedOnChange = debounce(
    /** @param {Event} event */
    (event) => {
      if (event instanceof QuantitySelectorUpdateEvent) this.#onQuantityChange(event);
    },
    300
  );
  /** @type {Promise<any> | null} */
  #pendingCartFetch = null;

  /**
   * True when the event was dispatched from outside this cart-items-component (e.g.
   * `Shopify.actions.updateCart(...)` from an external app, or the SFAPI default
   * handler). Internal dispatchers (cart-discount-component, cart-note) live inside
   * `this` and either morph the section themselves or don't need a refresh — running
   * a fallback render in that case double-renders and can clobber form state.
   * @param {Event} event
   */
  #isExternalCartUpdate(event) {
    return !(event.target instanceof Node) || !this.contains(event.target);
  }

  /** @param {CartDiscountUpdateEvent} event */
  #handleDiscountUpdate = (event) => {
    const external = this.#isExternalCartUpdate(event);
    event.promise
      ?.then(({ detail }) => {
        const sectionsHtml = detail?.sections?.[this.sectionId];
        if (sectionsHtml) {
          morphSection(this.sectionId, sectionsHtml, { mode: this.isDrawer ? 'hydration' : 'full' });
          this.#updateCartQuantitySelectorButtonStates();
        } else if (external) {
          // External caller (Shopify.actions.updateCart or SFAPI default handler) didn't
          // attach sections; refetch so the discount UI reflects the post-mutation cart.
          // Internal cart-discount-component morphs the section itself — no fallback needed.
          sectionRenderer.renderSection(this.sectionId, {
            cache: false,
            mode: this.isDrawer ? 'hydration' : 'full',
          });
        }
      })
      .catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[cart-items] Event promise rejected:', error);
      });
  };

  /** @param {CartNoteUpdateEvent} event */
  #handleNoteUpdate = (event) => {
    // Internal cart-note dispatches don't need a section refresh — the user typed the
    // value and the textarea retains it. Only external callers need the UI synced.
    if (!this.#isExternalCartUpdate(event)) return;
    event.promise
      ?.then(({ detail }) => {
        const sections = /** @type {Record<string, string> | undefined} */ (detail?.sections);
        const sectionsHtml = sections?.[this.sectionId];
        if (sectionsHtml) {
          morphSection(this.sectionId, sectionsHtml, { mode: this.isDrawer ? 'hydration' : 'full' });
        } else {
          sectionRenderer.renderSection(this.sectionId, {
            cache: false,
            mode: this.isDrawer ? 'hydration' : 'full',
          });
        }
      })
      .catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[cart-items] Event promise rejected:', error);
      });
  };

  connectedCallback() {
    super.connectedCallback();

    document.addEventListener(StandardEvents.cartLinesUpdate, this.#handleCartUpdate);
    document.addEventListener(ThemeEvents.quantitySelectorUpdate, this.#debouncedOnChange);
    document.addEventListener(StandardEvents.cartDiscountUpdate, this.#handleDiscountUpdate);
    document.addEventListener(StandardEvents.cartNoteUpdate, this.#handleNoteUpdate);
    this.addEventListener('click', this.#handleKagesCustomTextAdd);
    this.#refreshAddonQuantityLimits();
  }

  disconnectedCallback() {
    super.disconnectedCallback();

    document.removeEventListener(StandardEvents.cartLinesUpdate, this.#handleCartUpdate);
    document.removeEventListener(ThemeEvents.quantitySelectorUpdate, this.#debouncedOnChange);
    document.removeEventListener(StandardEvents.cartDiscountUpdate, this.#handleDiscountUpdate);
    document.removeEventListener(StandardEvents.cartNoteUpdate, this.#handleNoteUpdate);
    this.removeEventListener('click', this.#handleKagesCustomTextAdd);
  }

  /**
   * Adds the $60 Customized Text line directly from an enclosure in the cart drawer.
   * @param {MouseEvent} event
   */
  #handleKagesCustomTextAdd = async (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const button = target.closest('[data-cart-custom-text-add]');
    if (!(button instanceof HTMLButtonElement) || !this.contains(button)) return;

    const root = button.closest('[data-cart-custom-text]');
    const input = root?.querySelector('[data-cart-custom-text-input]');
    const status = root?.querySelector('[data-cart-custom-text-status]');
    if (!(input instanceof HTMLInputElement)) return;

    const customizedText = input.value.trim();
    if (!customizedText) {
      input.focus();
      if (status) status.textContent = 'Enter the customized text first.';
      return;
    }

    button.disabled = true;
    if (status) status.textContent = 'Adding…';

    const deferredPromise = CartLinesUpdateEvent.createPromise();
    document.dispatchEvent(new CartLinesUpdateEvent({
      action: 'add',
      context: 'cart',
      lines: [{ merchandiseId: '52621410107690', quantity: 1 }],
      promise: deferredPromise.promise,
    }));

    try {
      const response = await fetch(Theme.routes.cart_add_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          items: [{
            id: 52621410107690,
            quantity: 1,
            properties: {
              'For Product': button.dataset.parentProductTitle || '',
              'Customized Text': customizedText,
              '_parent_product_id': button.dataset.parentProductId || '',
              '_parent_variant_id': button.dataset.parentVariantId || '',
              '_parent_line_key': button.dataset.parentLineKey || '',
            },
          }],
          sections: this.sectionId,
        }),
      });
      const data = await response.json();
      if (!response.ok || data.status) throw new Error(data.description || data.message || 'Could not add customized text.');

      const cartResponse = await fetch(`${Theme.routes.cart_url}.json`, { headers: { Accept: 'application/json' } });
      const cart = await cartResponse.json();
      deferredPromise.resolve({
        cart: CartLinesUpdateEvent.createCartFromAjaxResponse(cart),
        detail: { sections: data.sections, items: cart.items, source: 'kages-cart-custom-text', itemCount: 1 },
      });
    } catch (error) {
      deferredPromise.reject(error);
      button.disabled = false;
      if (status) status.textContent = error instanceof Error ? error.message : 'Could not add customized text.';
    }
  };

  /**
   * Handles QuantitySelectorUpdateEvent change event.
   * @param {QuantitySelectorUpdateEvent} event - The event.
   */
  #onQuantityChange(event) {
    if (!(event.target instanceof Node) || !this.contains(event.target)) return;

    const { quantity, cartLine: line } = event.detail;

    // Cart items require a line number
    if (!line) return;

    if (quantity === 0) {
      return this.onLineItemRemove(line);
    }

    // Validate only increases. Decreases and removals retain Horizon's native lifecycle.
    const selector = this.querySelector(`cart-quantity-selector-component input[data-cart-line="${line}"]`)?.closest('cart-quantity-selector-component');
    const input = selector?.querySelector('input');
    const isAddon = selector?.dataset.kagesAddon === 'true';
    const currentQuantity = Number(input?.dataset.cartQuantity || input?.defaultValue || 0);
    if (isAddon && quantity > currentQuantity) {
      this.#validateAddonIncrease(line, quantity);
      return;
    }
    this.updateQuantity({ line, quantity, action: 'change' });
    const lineItemRow = this.refs.cartItemRows[line - 1];

    if (!lineItemRow) return;

    const textComponent = /** @type {TextComponent | undefined} */ (lineItemRow.querySelector('text-component'));
    textComponent?.shimmer();
  }

  #addonLimitsRequest = null;
  #addonWidthCache = new Map();

  async #getEnclosureCapacity(parentId, parentItem) {
    const cached = this.#addonWidthCache.get(parentId);
    if (cached > 0) return cached;
    let width = Number(document.querySelector(`[data-enclosure-addons][data-parent-product-id="${parentId}"]`)?.dataset.maxWidth || 0);
    if (!width && parentItem?.url) {
      const response = await fetch(parentItem.url, { credentials: 'same-origin' });
      if (response.ok) {
        const html = new DOMParser().parseFromString(await response.text(), 'text/html');
        width = Number(html.querySelector(`[data-enclosure-addons][data-parent-product-id="${parentId}"]`)?.dataset.maxWidth || 0);
      }
    }
    if (width > 0) this.#addonWidthCache.set(parentId, width);
    return width;
  }

  #setAddonPlusState(selector, maximum, current) {
    const input = selector?.querySelector('input');
    if (!input) return;
    input.max = String(maximum);
    selector.updateButtonStates?.();
    // Explicitly disable the native + control. Its state is not managed
    // by the enclosing cart-items component's refs.
    const plus = selector.querySelector('button[name="plus"]');
    if (plus) plus.disabled = current >= maximum;
  }

  async #refreshAddonQuantityLimits() {
    if (this.#addonLimitsRequest) return this.#addonLimitsRequest;
    this.#addonLimitsRequest = (async () => {
      try {
        const response = await fetch(`${Theme.routes.cart_url}.json`, { credentials: 'same-origin', cache: 'no-store' });
        if (!response.ok) return;
        const cart = await response.json();
        for (let index = 0; index < cart.items.length; index++) {
          const item = cart.items[index];
          const selector = this.querySelector(`cart-quantity-selector-component input[data-cart-line="${index + 1}"]`)?.closest('cart-quantity-selector-component');
          const input = selector?.querySelector('input');
          if (!input) continue;
          const parentId = String(item.properties?._addon_parent_product_id || '');
          const addonWidth = Number(item.properties?._addon_product_width || 0);
          if (!parentId || addonWidth <= 0) {
            // Never alter the parent enclosure or ordinary product controls.
            if (selector.dataset.kagesAddon === 'true') {
              input.max = input.dataset.kagesOriginalMax || '';
              delete selector.dataset.kagesAddon;
              delete input.dataset.kagesOriginalMax;
              selector.updateButtonStates?.();
            }
            continue;
          }
          selector.dataset.kagesAddon = 'true';
          const parents = cart.items.filter((entry) => String(entry.product_id) === parentId && !entry.properties?._addon_parent_product_id);
          const count = parents.reduce((sum, entry) => sum + Number(entry.quantity || 0), 0);
          const capacity = await this.#getEnclosureCapacity(parentId, parents[0]);
          let maximum = Number(item.quantity);
          if (capacity > 0 && count > 0) {
            const assigned = Number(item.properties._addon_enclosure_number || 1);
            if (assigned >= 1 && assigned <= count) {
              const used = cart.items.reduce((sum, entry) => {
                if (String(entry.properties?._addon_parent_product_id || '') !== parentId) return sum;
                if (Number(entry.properties?._addon_enclosure_number || 1) !== assigned) return sum;
                return sum + Number(entry.properties?._addon_product_width || 0) * Number(entry.quantity || 0);
              }, 0);
              maximum += Math.max(0, Math.floor((capacity - used + 0.001) / addonWidth));
            }
          }
          if (input.dataset.kagesOriginalMax === undefined) input.dataset.kagesOriginalMax = input.max;
          const originalMax = Number(input.dataset.kagesOriginalMax);
          if (originalMax > 0) maximum = Math.min(maximum, originalMax);
          this.#setAddonPlusState(selector, maximum, Number(item.quantity));
        }
      } catch (error) {
        console.warn('[cart-items] Unable to refresh add-on quantity limits', error);
      } finally {
        this.#addonLimitsRequest = null;
      }
    })();
    return this.#addonLimitsRequest;
  }

  #addonValidationPending = false;

  async #validateAddonIncrease(line, quantity) {
    const selector = this.querySelector(`cart-quantity-selector-component input[data-cart-line="${line}"]`)?.closest('cart-quantity-selector-component');
    const input = selector?.querySelector('input');
    let confirmedQuantity = Number(input?.defaultValue || 1);
    const restore = () => {
      if (input) {
        input.value = String(confirmedQuantity);
        input.setAttribute('value', String(confirmedQuantity));
        selector?.updateButtonStates?.();
      }
    };
    if (this.#addonValidationPending) { restore(); return; }
    this.#addonValidationPending = true;
    try {
      const response = await fetch(`${Theme.routes.cart_url}.json`, {
        credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
      });
      if (!response.ok) throw new Error('Unable to check available width.');
      const cart = await response.json();
      const item = cart.items[line - 1];
      if (!item) {
        throw new Error('The cart changed. Please try again.');
      }
      confirmedQuantity = Number(item.quantity || 1);
      const props = item.properties || {};
      if (props._addon_parent_product_id) {
        const id = String(props._addon_parent_product_id);
        const parents = cart.items.filter((entry) => String(entry.product_id) === id && !entry.properties?._addon_parent_product_id);
        const count = parents.reduce((sum, entry) => sum + Number(entry.quantity || 0), 0);
        if (!count) throw new Error('Add the matching enclosure before increasing this add-on.');
        const width = Number(props._addon_product_width);
        if (!Number.isFinite(width) || width < 0) throw new Error('Add-on width is missing.');
        const capacity = await this.#getEnclosureCapacity(id, parents[0]);
        if (!capacity) throw new Error('Enclosure width is unavailable. Quantity was not changed.');
        const used = Array(count).fill(0);
        const legacy = [];
        for (const entry of cart.items) {
          if (String(entry.properties?._addon_parent_product_id || '') !== id) continue;
          const addonWidth = Number(entry.properties._addon_product_width);
          if (!Number.isFinite(addonWidth) || addonWidth < 0) throw new Error('Add-on width is missing.');
          const amount = entry.key === item.key ? quantity : Number(entry.quantity || 0);
          const assigned = Number(entry.properties._addon_enclosure_number);
          if (Number.isInteger(assigned) && assigned >= 1 && assigned <= count) {
            used[assigned - 1] += addonWidth * amount;
          } else if (Number.isInteger(assigned) && assigned > count) {
            throw new Error('An add-on is assigned to an enclosure that is no longer present.');
          } else {
            for (let n = 0; n < amount; n++) legacy.push(addonWidth);
          }
        }
        for (const addonWidth of legacy.sort((a, b) => b - a)) {
          const slot = used.findIndex((value) => value + addonWidth <= capacity + 0.001);
          if (slot < 0) throw new Error('Width limit reached. This add-on will not fit.');
          used[slot] += addonWidth;
        }
        if (used.some((value) => value > capacity + 0.001)) {
          throw new Error(`Width limit reached. Each enclosure allows ${capacity}″ of add-ons.`);
        }
      }
      selector?.closest('.quantity-selector-wrapper')?.parentElement?.querySelector('[data-addon-width-error]')?.remove();
      this.updateQuantity({ line, quantity, action: 'change' });
      this.refs.cartItemRows[line - 1]?.querySelector('text-component')?.shimmer();
    } catch (error) {
      restore();
      // Keep feedback outside the quantity selector's flex layout.
      // Never append alerts to the parent enclosure row.
      if (input && input.closest('cart-quantity-selector-component')?.dataset.kagesAddon === 'true') {
        const wrapper = selector.closest('.quantity-selector-wrapper');
        const container = wrapper?.parentElement;
        if (container) {
          let message = container.querySelector('[data-addon-width-error]');
          if (!message) {
            message = document.createElement('div');
            message.dataset.addonWidthError = '';
            message.setAttribute('role', 'alert');
            message.style.cssText = 'display:block;clear:both;width:100%;box-sizing:border-box;margin:8px 0;padding:10px 12px;background:#fbf3ec;border:1px solid #f2c9ad;border-radius:8px;color:#9a470e;font-size:12px;line-height:1.5;';
            wrapper.insertAdjacentElement('afterend', message);
          }
          message.textContent = error instanceof Error ? error.message : 'Unable to validate width.';
        }
      }
      this.#refreshAddonQuantityLimits();
    } finally {
      this.#addonValidationPending = false;
    }
  }

  /**
   * Handles the line item removal.
   * @param {number} line - The line item index.
   */
  onLineItemRemove(line) {
    this.updateQuantity({
      line,
      quantity: 0,
      action: 'clear',
    });

    const cartItemRowToRemove = this.refs.cartItemRows[line - 1];

    if (!cartItemRowToRemove) return;

    const rowsToRemove = [
      cartItemRowToRemove,
      // Get all nested lines of the row to remove
      ...this.refs.cartItemRows.filter((row) => row.dataset.parentKey === cartItemRowToRemove.dataset.key),
    ];

    // If the cart item row is the last row, optimistically trigger the cart empty state
    const isEmptyCart = rowsToRemove.length == this.refs.cartItemRows.length;

    const template = document.getElementById('empty-cart-template');
    if (isEmptyCart && template instanceof HTMLTemplateElement) {
      const clone = document.importNode(template.content, true);

      startViewTransition(() => {
        document.getElementById('cart-drawer-heading')?.remove();
        this.replaceChildren(clone);
      }, [this.isDrawer ? 'empty-cart-drawer' : 'empty-cart-page']);

      return;
    }

    // Add class to the row to trigger the animation
    rowsToRemove.forEach((row) => {
      const remove = () => row.remove();

      if (prefersReducedMotion()) return remove();

      row.style.setProperty('--row-height', `${row.clientHeight}px`);
      row.classList.add('removing');

      // Remove the row after the animation ends
      onAnimationEnd(row, remove);
    });
  }

  /**
   * Updates the quantity.
   * @param {Object} config - The config.
   * @param {number} config.line - The line.
   * @param {number} config.quantity - The quantity.
   * @param {string} config.action - The action.
   */
  updateQuantity(config) {
    const cartPerformaceUpdateMarker = cartPerformance.createStartingMarker(`${config.action}:user-action`);

    this.#disableCartItems();

    const { line, quantity } = config;
    const { cartTotal } = this.refs;

    const cartItemsComponents = document.querySelectorAll('cart-items-component');
    const sectionsToUpdate = new Set([this.sectionId]);
    cartItemsComponents.forEach((item) => {
      if (item instanceof HTMLElement && item.dataset.sectionId) {
        sectionsToUpdate.add(item.dataset.sectionId);
      }
    });

    const body = JSON.stringify({
      line: line,
      quantity: quantity,
      sections: Array.from(sectionsToUpdate).join(','),
      sections_url: window.location.pathname,
    });

    cartTotal?.shimmer();

    const deferredUpdatePromise = CartLinesUpdateEvent.createPromise();
    const lineId = this.refs.cartItemRows[line - 1]?.dataset.key ?? '';
    this.dispatchEvent(
      new CartLinesUpdateEvent({
        action: config.action === 'change' && quantity > 0 ? 'update' : 'remove',
        context: 'cart',
        lines: [{ id: lineId, quantity }],
        promise: deferredUpdatePromise.promise,
      })
    );

    fetch(`${Theme.routes.cart_change_url}`, fetchConfig('json', { body }))
      .then((response) => {
        return response.text();
      })
      .then((responseText) => {
        const parsedResponseText = JSON.parse(responseText);

        resetShimmer(this);

        if (parsedResponseText.errors) {
          this.#handleCartError(line, parsedResponseText);
          deferredUpdatePromise.reject(new Error(parsedResponseText.errors));
          return;
        }

        const newSectionHTML = new DOMParser().parseFromString(
          parsedResponseText.sections[this.sectionId],
          'text/html'
        );

        // Grab the new cart item count from a hidden element
        const newCartHiddenItemCount = newSectionHTML.querySelector('[ref="cartItemCount"]')?.textContent;
        const newCartItemCount = newCartHiddenItemCount ? parseInt(newCartHiddenItemCount, 10) : 0;

        // Update data-cart-quantity for all matching variants
        this.#updateQuantitySelectors(parsedResponseText);

        deferredUpdatePromise.resolve({
          cart: CartLinesUpdateEvent.createCartFromAjaxResponse(parsedResponseText),
          detail: {
            sections: parsedResponseText.sections,
            items: parsedResponseText.items,
            itemCount: newCartItemCount,
            source: 'cart-items-component',
            didError: false,
          },
        });

        morphSection(this.sectionId, parsedResponseText.sections[this.sectionId], {
          mode: this.isDrawer ? 'hydration' : 'full',
        });

        this.#updateCartQuantitySelectorButtonStates();
        this.#refreshAddonQuantityLimits();
      })
      .catch((error) => {
        console.error(error);
        deferredUpdatePromise.reject(error);

        this.dispatchEvent(
          new CartErrorEvent({
            error: error?.message || 'Failed to update cart',
            code: 'SERVICE_UNAVAILABLE',
          })
        );
      })
      .finally(() => {
        this.#enableCartItems();
        cartPerformance.measureFromMarker(cartPerformaceUpdateMarker);
      });
  }

  /**
   * Handles the cart error.
   * @param {number} line - The line.
   * @param {Object} parsedResponseText - The parsed response text.
   * @param {string} parsedResponseText.errors - The errors.
   */
  #handleCartError = (line, parsedResponseText) => {
    const quantitySelector = this.refs.quantitySelectors[line - 1];
    const quantityInput = quantitySelector?.querySelector('input');

    if (!quantityInput) throw new Error('Quantity input not found');

    quantityInput.value = quantityInput.defaultValue;

    const cartItemError = this.refs[`cartItemError-${line}`];
    const cartItemErrorContainer = this.refs[`cartItemErrorContainer-${line}`];

    if (!(cartItemError instanceof HTMLElement)) throw new Error('Cart item error not found');
    if (!(cartItemErrorContainer instanceof HTMLElement)) throw new Error('Cart item error container not found');

    cartItemError.textContent = parsedResponseText.errors;
    cartItemErrorContainer.classList.remove('hidden');

    this.dispatchEvent(
      new CartErrorEvent({
        error: parsedResponseText.errors || 'Cart update failed',
        code: 'INVALID',
      })
    );
  };

  /**
   * Handles the cart update.
   *
   * @param {CartLinesUpdateEvent} event
   */
  #handleCartUpdate = (event) => {
    if (event.target === this) return;

    event.promise
      ?.then(async ({ detail }) => {
        const sections = detail?.sections;
        const cartItemsHtml = sections?.[this.sectionId];
        // Animate empty → non-empty in the drawer (possible in squeeze mode
        // where the page is interactive alongside the open drawer). This also
        // needs the response stylesheet because it adds the cart summary markup.
        const wasEmptyCartDrawer = this.isDrawer && this.querySelector('[data-cart-drawer-empty]') !== null;
        /** @type {'hydration' | 'full'} */
        const mode = this.isDrawer ? 'hydration' : 'full';
        const morphOptions = {
          mode,
          injectStylesheet: wasEmptyCartDrawer,
        };

        if (cartItemsHtml) {
          const existingKeys = new Set(this.refs.cartItemRows?.map((row) => row.dataset.key) ?? []);

          if (wasEmptyCartDrawer) {
            startViewTransition(() => {
              morphSection(this.sectionId, cartItemsHtml, morphOptions);
            }, ['fill-cart-drawer']);
          } else {
            await morphSection(this.sectionId, cartItemsHtml, morphOptions);
          }

          // Animate newly added rows (reverse of the remove animation).
          if (!wasEmptyCartDrawer && !prefersReducedMotion()) {
            for (const row of this.refs.cartItemRows ?? []) {
              if (!existingKeys.has(row.dataset.key)) {
                row.classList.add('adding');
                onAnimationEnd(row, () => row.classList.remove('adding'));
              }
            }
          }

          // Update button states for all cart quantity selectors after morph
          this.#updateCartQuantitySelectorButtonStates();
          this.#refreshAddonQuantityLimits();
        } else {
          sectionRenderer.renderSection(this.sectionId, { cache: false, ...morphOptions });
        }
      })
      .catch((error) => {
        if (error?.name !== 'AbortError') console.warn('[cart-items] Event promise rejected:', error);
      });
  };

  /**
   * Disables the cart items.
   */
  #disableCartItems() {
    this.classList.add('cart-items-disabled');
  }

  /**
   * Enables the cart items.
   */
  #enableCartItems() {
    this.classList.remove('cart-items-disabled');
  }

  /**
   * Updates quantity selectors for all matching variants in the cart.
   * @param {Object} updatedCart - The updated cart object.
   * @param {Array<{variant_id: number, quantity: number}>} [updatedCart.items] - The cart items.
   */
  #updateQuantitySelectors(updatedCart) {
    if (!updatedCart.items) return;

    for (const item of updatedCart.items) {
      const variantId = item.variant_id.toString();
      const selectors = document.querySelectorAll(`quantity-selector-component[data-variant-id="${variantId}"]`);

      for (const selector of selectors) {
        const input = selector.querySelector('input[data-cart-quantity]');
        if (!input) continue;

        input.setAttribute('data-cart-quantity', item.quantity.toString());

        // Update the quantity selector's internal state
        if ('updateCartQuantity' in selector && typeof selector.updateCartQuantity === 'function') {
          selector.updateCartQuantity();
        }
      }
    }
  }

  /**
   * Updates button states for all cart quantity selector components.
   */
  #updateCartQuantitySelectorButtonStates() {
    for (const selector of document.querySelectorAll('cart-quantity-selector-component')) {
      /** @type {any} */ (selector).updateButtonStates?.();
    }
  }

  async fetchCartData() {
    if (this.#pendingCartFetch) return this.#pendingCartFetch;

    this.#pendingCartFetch = (async () => {
      const response = await fetch(`${Theme.routes.cart_url}.json`, {
        headers: { Accept: 'application/json' },
        credentials: 'same-origin',
      });
      if (!response.ok) throw new Error(`Failed to fetch cart: ${response.status} ${response.statusText}`);
      const data = await response.json();
      return data;
    })().finally(() => {
      this.#pendingCartFetch = null;
    });

    return this.#pendingCartFetch;
  }

  /**
   * Gets the section id.
   * @returns {string} The section id.
   */
  get sectionId() {
    const { sectionId } = this.dataset;

    if (!sectionId) throw new Error('Section id missing');

    return sectionId;
  }

  /**
   * @returns {boolean} Whether the component is a drawer.
   */
  get isDrawer() {
    return this.dataset.drawer !== undefined;
  }
}

if (!customElements.get('cart-items-component')) {
  customElements.define('cart-items-component', CartItemsComponent);
}
