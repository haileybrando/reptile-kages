import { StandardEvents } from '@shopify/events';

const number = (value) => Number.parseFloat(String(value ?? '').replace(/[^0-9.-]/g, '')) || 0;
const roots = () => [...document.querySelectorAll('[data-enclosure-addons]')];
const parentId = (root) => String(root.dataset.parentProductId || '');
let cart = { items: [] };
let ready = false;
let syncing = null;
const pending = new Map();

function enclosureQuantity(id) {
  return cart.items.reduce((sum, item) => {
    if (String(item.product_id) !== id || item.properties?._addon_parent_product_id) return sum;
    return sum + Math.max(0, Number(item.quantity) || 0);
  }, 0);
}

function usage(id, capacity) {
  const quantity = enclosureQuantity(id);
  const widths = Array(quantity).fill(0);
  if (!quantity) return widths;
  const addons = cart.items.filter((item) => String(item.properties?._addon_parent_product_id || '') === id);
  const unassigned = [];
  for (const item of addons) {
    const properties = item.properties || {};
    const width = number(properties._addon_product_width);
    const count = Math.max(0, Number(item.quantity) || 0);
    if (!width || !count) continue;
    const assigned = Number.parseInt(properties._addon_enclosure_number, 10);
    if (assigned >= 1 && assigned <= quantity) {
      widths[assigned - 1] += width * count;
    } else {
      for (let i = 0; i < count; i++) unassigned.push(width);
    }
  }
  // Existing unnumbered add-ons are allocated conservatively; do not discard their width.
  for (const width of unassigned.sort((a, b) => b - a)) {
    const index = widths.findIndex((used) => used + width <= capacity + 0.001);
    if (index !== -1) widths[index] += width;
    else widths[widths.indexOf(Math.min(...widths))] += width;
  }
  for (const reservation of pending.get(id) || []) {
    if (reservation.enclosure <= quantity) widths[reservation.enclosure - 1] += reservation.width;
  }
  return widths;
}

function selectEnclosure(root, addonWidth) {
  const id = parentId(root);
  const quantity = enclosureQuantity(id);
  if (!quantity) return 0;
  const capacity = number(root.dataset.maxWidth);
  if (!capacity || !addonWidth) return 1;
  return usage(id, capacity).findIndex((used) => used + addonWidth <= capacity + 0.001) + 1;
}

function refresh() {
  for (const root of roots()) {
    const capacity = number(root.dataset.maxWidth);
    const widths = usage(parentId(root), capacity);
    let widthOptions = 0;
    let blockedOptions = 0;
    for (const card of root.querySelectorAll('[data-addon-card]')) {
      const width = number(card.dataset.addonWidth);
      const button = card.querySelector('button[name="add"]');
      if (!button) continue;
      if (button.dataset.initiallyUnavailable === undefined) {
        button.dataset.initiallyUnavailable = String(button.disabled);
      }
      const cannotFit = ready && selectEnclosure(root, width) === 0;
      const unavailable = button.dataset.initiallyUnavailable === 'true';
      card.dataset.fitBlocked = String(cannotFit);
      button.dataset.fitBlocked = String(cannotFit);
      button.disabled = unavailable || cannotFit;
      if (cannotFit) {
        button.title = 'No enclosure has enough remaining width';
      } else {
        button.removeAttribute('title');
      }
      if (width > 0 && button.dataset.initiallyUnavailable !== 'true') {
        widthOptions++;
        if (cannotFit) blockedOptions++;
      }
    }
    const message = root.querySelector('[data-limit-message]');
    if (message) message.hidden = !(ready && widthOptions > 0 && blockedOptions === widthOptions);
    const meter = root.querySelector('[data-addon-width-meter]');
    if (meter) {
      const total = capacity * widths.length;
      const used = widths.reduce((sum, value) => sum + value, 0);
      const heading = meter.querySelector('[data-width-meter-capacity]');
      const label = meter.querySelector('[data-width-meter-label]');
      const fill = meter.querySelector('[data-width-meter-fill]');
      if (heading) heading.textContent = `${widths.length} enclosure${widths.length === 1 ? '' : 's'} × ${capacity}″ = ${total}″ available`;
      if (label) label.textContent = `${Math.max(0, total - used)}″ remaining`;
      if (fill) fill.style.width = `${total ? Math.min(100, 100 * used / total) : 0}%`;
    }
  }
}

async function syncCart() {
  if (syncing) return syncing;
  syncing = (async () => {
    try {
      const response = await fetch(`${window.Shopify?.routes?.root || '/'}cart.js`, {
        credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store'
      });
      if (!response.ok) throw new Error(`Cart HTTP ${response.status}`);
      cart = await response.json();
      ready = true;
      pending.clear();
      refresh();
    } catch (error) {
      console.warn('[enclosure-add-ons] Could not validate cart width', error);
      ready = false;
      // Fail closed rather than allowing an unchecked add-on.
      refresh();
    } finally {
      syncing = null;
    }
  })();
  return syncing;
}

document.addEventListener('submit', (event) => {
  const form = event.target;
  if (!(form instanceof HTMLFormElement)) return;
  const root = form.closest('[data-enclosure-addons]');
  const card = form.closest('[data-addon-card]');
  if (!root || !card) return;
  const width = number(card.dataset.addonWidth);
  const enclosure = ready ? selectEnclosure(root, width) : 0;
  if (!enclosure) {
    event.preventDefault();
    event.stopImmediatePropagation();
    refresh();
    if (!ready) syncCart();
    return;
  }
  const assignment = form.querySelector('[name="properties[_addon_enclosure_number]"]');
  if (assignment) assignment.value = String(enclosure);
  const label = form.querySelector('[name="properties[For Product]"]');
  if (label) label.value = `${root.dataset.parentProductTitle} (${enclosure})`;
  const id = parentId(root);
  pending.set(id, [...(pending.get(id) || []), { enclosure, width }]);
  refresh();
}, true);

document.addEventListener(StandardEvents.cartLinesUpdate, (event) => {
  if (event.promise) event.promise.then(syncCart, syncCart);
  else syncCart();
});
document.addEventListener('DOMContentLoaded', syncCart, { once: true });
if (document.readyState !== 'loading') syncCart();